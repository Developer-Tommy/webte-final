<?php
namespace App\Model;

class Placement
{

    private int $id;
    private int $person_id;
    private int $oh_id;
    private int $placing;
    private string $discipline;

    private string $city;


}
