function diceRoll(){
    alert("5");
}