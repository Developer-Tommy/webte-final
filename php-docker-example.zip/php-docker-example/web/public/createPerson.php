<!doctype html>

<html lang="en">
<head>
    <meta charset="utf-8">

    <title>Olympic Winners</title>

</head>

<body>

<h1>Create new person</h1>

<?php
include "partials/personForm.php";
?>

</body>
</html>